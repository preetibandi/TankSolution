﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using ExcelDataReader;
using Models;
using Models.DTOs;

namespace DataAccessLayer
{
    public class OverHeadTankData
    {
        public TankInfo GetAllOverHeadTankDetails()
        {
            var tankInfo = new TankInfo();

            string con =
  @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./OverHeadTankRepo.xlsx;" +
  @"Extended Properties='Excel 8.0;HDR=Yes;'";
            using (OleDbConnection connection = new OleDbConnection(con))
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("select * from [Sheet3$]", connection);
                using (OleDbDataReader dr = command.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        tankInfo.TankName = dr[1].ToString();
                        tankInfo.TankCapacity = int.Parse(dr[2].ToString());
                    }
                }
            }

            return tankInfo;
        }

        public TankDetails GetOverHeadTankDetailsByTankId(int tankId)
        {
            var tankDetails = new TankDetails() { TankId = tankId , TankTransactionDetails = new List<TankTransactionDetails>());

            string con =
  @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./OverHeadTankRepo.xlsx;" +
  @"Extended Properties='Excel 8.0;HDR=Yes;'";
            using (OleDbConnection connection = new OleDbConnection(con))
            {
                connection.Open();
                DataTable dt = new DataTable();
                OleDbCommand command = new OleDbCommand("select * from [Sheet2$] where TankId = " + tankId, connection);

                using (OleDbDataAdapter da = new OleDbDataAdapter())
                {
                    da.SelectCommand = command;
                    da.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {
                        var item = new TankTransactionDetails();
                        item.IsInput = dr[2].ToString();
                        item.WaterDifference = int.Parse(dr[3].ToString());
                        item.WaterLevel = int.Parse(dr[4].ToString());
                        item.CreateDateTime = DateTime.ParseExact(dr[5].ToString(), "yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture);
                        tankDetails.TankTransactionDetails.Add(item);
                    }
                }
            }

            return tankDetails;
        }
    }
}
