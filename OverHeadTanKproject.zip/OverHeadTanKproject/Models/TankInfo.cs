﻿using System;

namespace Models
{
    public class TankInfo
    {
        public string TankName { get; set; }
        public int TankCapacity { get; set; }
        public DateTime CreatedDateTime { get; set; }

    }
}
