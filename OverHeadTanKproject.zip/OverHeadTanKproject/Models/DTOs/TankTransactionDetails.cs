﻿using System;

namespace Models.DTOs
{
    public class TankTransactionDetails
    {
        public long TankTransactionId { get; set; }
        public string IsInput { get; set; }
        public int WaterDifference { get; set; }
        public int WaterLevel { get; set; }
        public DateTime CreateDateTime { get; set; }
        public int PreviousWaterLevel { get; set; }

    }
}
