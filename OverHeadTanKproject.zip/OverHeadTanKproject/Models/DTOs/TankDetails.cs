﻿using System;
using System.Collections.Generic;

namespace Models.DTOs
{
    public class TankDetails
    {
        public long TankId { get; set; }
        public string TankName { get; set; }
        public List<TankTransactionDetails> TankTransactionDetails { get; set; }

    }
}
