﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace TankAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TankDetailsController : ControllerBase
    {

        [HttpGet]
        [Route("api/tanks/getAllTankInfo")]
        public IActionResult GetAllOverHeadTankDetails()
        {
            var response = new OverHandleTankService().GetAllOverHeadTankDetails();

            return Ok(response);
        }

        [HttpGet]
        [Route("api/tanks/getTankById")]
        public IActionResult GetTankDetailsById(int id)
        {
            var response = new OverHandleTankService().GetOverHeadTankDetailsByTankId(id);

            return Ok(response);
        }
    }
}
