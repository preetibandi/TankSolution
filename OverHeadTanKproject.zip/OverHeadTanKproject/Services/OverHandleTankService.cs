﻿using DataAccessLayer;
using Models;
using Models.DTOs;
using System;

namespace Services
{
    public class OverHandleTankService
    {
        public TankInfo GetAllOverHeadTankDetails()
        {
            return new OverHeadTankData().GetAllOverHeadTankDetails();
        }

        public TankDetails GetOverHeadTankDetailsByTankId(int tankId)
        {
            var result = new OverHeadTankData().GetOverHeadTankDetailsByTankId(tankId);

            return result;
        }
        }
}
